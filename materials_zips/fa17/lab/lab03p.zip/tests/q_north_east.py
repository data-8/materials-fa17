test = {
  'name': '',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> northern_markets.sort(0)
          MarketName                    | city           | State  | y       | x
          Ester Community Market        | Ester          | Alaska | 64.8459 | -148.01
          Fairbanks Downtown Market     | Fairbanks      | Alaska | 64.8444 | -147.72
          Highway's End Farmers' Market | Delta Junction | Alaska | 64.0385 | -145.733
          Nenana Open Air Market        | Nenana         | Alaska | 64.5566 | -149.096
          Tanana Valley Farmers Market  | Fairbanks      | Alaska | 64.8628 | -147.781
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
