test = {
  'name': 'Question 2_6',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> np.round(faithful_residual_sd,2) == 5.89
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
